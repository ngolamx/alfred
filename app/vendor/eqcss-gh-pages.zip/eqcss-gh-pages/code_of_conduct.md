# The Hacker Code of Conduct

This project abides by the following code of conduct:

Both this project and its maintainers are inclusive to all people, and welcome all ideas. True diversity of thought builds perspective and benefits all of us. Diversity depends on the presence of differing opinions, this code of conduct establishes acceptable professional behaviour and does not police speech or opinions.

- No ad-hominem attacks will be tolerated against any project maintainer, contributor, or user
- No prolonged disturbance of shared collaborative space will be tolerated
- The values we uphold are: excellence, innovation, fairness, and freedom

Violations of the above rules will be handled on a case-by-case basis, in a direct and reasonable way.
